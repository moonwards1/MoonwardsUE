Python code inside this folder MUST be GPL and should NOT be linked or loaded by UnrealEngine. Call these scripts only via an external process.

[Read full GPL license](GPL)