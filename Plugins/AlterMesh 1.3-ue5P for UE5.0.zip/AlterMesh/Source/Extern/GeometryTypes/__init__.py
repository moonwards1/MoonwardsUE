def used_for_object(obj):
    False

def get_defaults(obj):
    pass