# AlterMesh
Use geometry nodes in Unreal

## Installation
Just clone or download zip and extract inside your Plugins folder.

## Support
discord.gg/kdUW3w6taQ

## Roadmap
https://trello.com/b/U6LZV7zO/altermesh

## Contributing
Feel free to make pull requests on main

main = development branch
numbered branches = releases

## License

Python scripts under /Plugins/AlterMesh/Source/Extern are GPL and all new python code placed under /Extern/ should be GPL too, and should NOT be linked or loaded by any Game/Engine code. [Read full GPL license](https://www.gnu.org/licenses/gpl-3.0.html)

The rest of AlterMesh uses a proprietary license: [Read full text](LICENSE)

Games and Software created using AlterMesh can choose any license compatible with the above and with UnrealEngine license.
